<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1351182531694" ID="ID_1749153312" MODIFIED="1351182549373" TEXT="Wohnungssuche">
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1351182534713" ID="ID_1245648218" LINK="http://www.immobilienscout24.de/Suche/S-20/Wohnung-Miete/Umkreissuche/Berlin/14195/220099/2505104/-/-/2/3,00-/-/EURO-800,00-1000,00?enteredFrom=result_list" MODIFIED="1351184214887" POSITION="right" TEXT="Wohnung in Dahlem Mietwohnungen im Umkreis von 14195 Berlin: Ihre Suchkriterien: ab 3 Zimmer, 800 - 1.000 EUR Kaltmiete im Umkreis von 2 km von Berlin">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<attribute NAME="script1" VALUE="Binding binding = new Binding();&#xa;binding.setVariable(&quot;c&quot;, c);&#xa;binding.setVariable(&quot;node&quot;, node);&#xa;new GroovyShell(binding).evaluate(new File(c.getMap().getFile().getParent(), &apos;immoscout.groovy&apos;).text);"/>
<node COLOR="#00b439" CREATED="1351183174050" FOLDED="true" ID="ID_1201547317" MODIFIED="1351186581689" TEXT="Uninteressant">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1351186578442" ID="ID_1035435460" MODIFIED="1351186581165" TEXT=" ">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>
